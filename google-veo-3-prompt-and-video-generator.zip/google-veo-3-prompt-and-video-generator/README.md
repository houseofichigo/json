# Google Veo 3 Video Generator Workflow

## Overview

This n8n workflow automates AI-powered video generation using Google's Veo 3 model via Leonardo.ai. It transforms text descriptions into cinematic videos by leveraging Claude 4 Sonnet to craft optimized prompts and Leonardo.ai's API to generate videos, which are then automatically uploaded to Google Drive.

## Key Features

- **AI-Powered Prompt Optimization**: Uses Claude 4 Sonnet to transform simple descriptions into professional Veo 3 prompts
- **Automated Video Generation**: Generates videos using Google's Veo 3 model through Leonardo.ai
- **Google Drive Integration**: Automatically uploads generated videos to a specified Google Drive folder
- **Wikipedia Research**: Optional Wikipedia tool for enriching prompts with factual information
- **Cinematic Control**: Supports advanced camera movements, shot composition, and audio cues

## Workflow Components

### 1. **Manual Trigger**
- Starts the workflow when you click "Execute workflow"
- No external triggers needed

### 2. **Video Context** (Set Node)
- Define your video concept in the `context` field
- Example: "vlog style video of a star wars stormtrooper-like character digging for nuclear uranium deposits in a desert"

### 3. **Veo3 Video Prompt Generator** (AI Agent)
- Uses Claude 4 Sonnet to transform your context into a professional Veo 3 prompt
- Follows Google Veo 3's optimal prompt structure:
  - Subject
  - Context
  - Action
  - Style
  - Camera Motion
  - Composition
  - Ambiance
  - Audio
- Character limit: 1450 characters (Leonardo.ai API constraint)

### 4. **LEO - Generate Text to Motion** (HTTP Request)
- Sends the optimized prompt to Leonardo.ai's text-to-video API
- Configuration:
  - Model: VEO3
  - Resolution: 720p
  - Privacy: Non-public videos

### 5. **Wait** (4 minutes)
- Video generation typically takes 3-4 minutes
- Built-in wait ensures the video is ready before retrieval

### 6. **Leo - Get videoId** (HTTP Request)
- Retrieves the generated video's metadata
- Extracts the video URL for download

### 7. **Video URL** (Set Node)
- Extracts the MP4 URL from the response

### 8. **Download Video** (HTTP Request)
- Downloads the generated video file

### 9. **UPLOAD VIDEO** (Google Drive)
- Uploads the video to your specified Google Drive folder
- Names the file using the generation ID

## Prerequisites

### Required Accounts
1. **Leonardo.ai Account**
   - Sign up at [Leonardo.ai](https://leonardo.ai)
   - API access required
   - Sufficient credits for video generation

2. **Anthropic API Key**
   - For Claude 4 Sonnet access
   - Get your API key from [Anthropic Console](https://console.anthropic.com)

3. **Google Account**
   - For Google Drive storage
   - OAuth2 authentication required

### n8n Credentials Setup

1. **Leonardo.ai Custom Auth**
   - Create HTTP Custom Auth credential
   - Add your Leonardo.ai API key as Bearer token

2. **Anthropic API**
   - Create Anthropic API credential
   - Add your API key

3. **Google Drive OAuth2**
   - Create Google Drive OAuth2 credential
   - Authorize access to your Google Drive

## Configuration

### 1. Google Drive Folder
- Update the `folderId` in the "UPLOAD VIDEO" node
- Replace with your own Google Drive folder ID

### 2. Video Context
- Modify the `context` value in the "Video Context" node
- Be descriptive but concise
- Include style, mood, and any specific requirements

### 3. Video Settings (Optional)
- Resolution: Currently set to 720p
- Can be modified in the "LEO - Generate Text to Motion" node
- Options: RESOLUTION_480, RESOLUTION_720, RESOLUTION_1080

## Usage Instructions

1. **Import the Workflow**
   - Copy the workflow JSON
   - Import into your n8n instance

2. **Configure Credentials**
   - Set up all required credentials (see Prerequisites)
   - Test each credential to ensure proper connection

3. **Set Your Video Context**
   - Edit the "Video Context" node
   - Enter your desired video description

4. **Execute the Workflow**
   - Click "Execute workflow"
   - Monitor progress (total time: ~5 minutes)

5. **Access Your Video**
   - Check your Google Drive folder
   - Video will be named with the generation ID

## Tips for Better Results

### Prompt Crafting
- Be specific about visual elements
- Include camera movements (pan, zoom, tracking shot)
- Describe lighting and ambiance
- Specify audio elements (music genre, sound effects)

### Example Contexts
```
"A cyberpunk hacker in a neon-lit room typing frantically on multiple keyboards, 
camera slowly pushes in, dramatic electronic music"

"Peaceful sunrise over misty mountains, drone shot pulling back to reveal 
a lone hiker, ambient nature sounds with gentle orchestral score"

"Stop-motion style animation of cookies baking in an oven, time-lapse effect, 
warm lighting, cozy kitchen sounds"
```

### Limitations
- Videos are 5-8 seconds long
- 1450 character limit for prompts
- Processing time: 3-4 minutes per video
- Resolution maximum: 1080p

## Troubleshooting

### Common Issues

1. **"Generation not ready" error**
   - Increase the wait time (currently 4 minutes)
   - Some complex videos may take longer

2. **Authentication errors**
   - Verify all API keys are correct
   - Check credential configurations

3. **Google Drive upload fails**
   - Ensure OAuth2 is properly authorized
   - Verify folder ID exists and is accessible

## Advanced Customization

### Adding More AI Tools
- The workflow includes Wikipedia for research
- Add more tools to the AI Agent for enhanced capabilities
- Examples: Web search, image analysis, data retrieval

### Batch Processing
- Modify to process multiple contexts
- Add a loop or use a spreadsheet trigger
- Implement error handling for failed generations

## Credits & License

**Author**: AlexK1919  
**License**: Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)  
**Products Used**: 
- [Leonardo.ai](https://leonardo.ai) - Video generation platform
- [Google Drive](https://drive.google.com/) - Cloud storage
- [Anthropic Claude](https://anthropic.com) - AI prompt optimization

---

For more n8n workflows and automation tips, join the [WotAI Community](https://wotai.co/community)